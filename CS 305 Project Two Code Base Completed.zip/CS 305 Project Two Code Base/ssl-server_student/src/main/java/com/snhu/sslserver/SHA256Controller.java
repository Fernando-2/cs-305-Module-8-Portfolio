package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SHA256Controller {

    @RequestMapping("/hash")
    public String getHash() {

        String data = "Fernando Rivas - CS305 Project Two June 2026";

        StringBuilder hash = new StringBuilder();

        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedHash = digest.digest(data.getBytes());

            for (byte b : encodedHash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hash.append('0');
                }
                hash.append(hex);
            }
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

        return "<h2>Name:</h2>" + "Fernando Rivas"
                + "<br><h2>Unique Data String:</h2>" + data
                + "<br><h2>SHA-256 Hash:</h2>" + hash.toString();
    }
}